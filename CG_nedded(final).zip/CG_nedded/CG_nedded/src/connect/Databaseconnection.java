/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connect;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;


/**
 *
 * @author shaha
 */
public class Databaseconnection {
      private Connection con;
      private static Databaseconnection dbc;
    private Databaseconnection(){
     try{
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("loaded");
            
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bus","root","");
              System.out.println("connect");
            /*localhost = hostname, 3306 = portnumber, user = databasename, root = databaseusername...
              no need of password write now...*/
          //  st = con.createStatement();"jdbc:mysql://localhost:3306/Project","root",""
        
            
        }
        catch(Exception ex){
            System.out.println("Error: "+ex);
        }
    }
    public static Databaseconnection getDatabaseconnection()
    {
        if(dbc==null)
        {
            dbc = new Databaseconnection();
        }
        return dbc;
    }
     public  Connection getConnection()
     {
         return con;
     }
    
}
