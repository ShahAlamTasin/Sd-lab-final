/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cg_nedded;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import javax.swing.JOptionPane;
import cg_nedded.Crud_panel;
import connect.Databaseconnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author shaha
 */

public class Datashow extends javax.swing.JFrame {

    private Connection con;
     private int busseat;
      String pasangername;
      boolean h= false; 
      boolean boo= false; 
      public int quantityn,contact;
      String name,placen;
      int quantityout,l=1;
  String emailpass;
    public Datashow() {//connection  to database
        initComponents();
        Databaseconnection dbc = Databaseconnection.getDatabaseconnection();
        con = dbc.getConnection();
    }
    public Datashow(String pass){//constructor for value passing
        emailpass= pass;
        System.out.println(pass);
    }

     public String sendMail(String Email,String Password,String ToEmail,String Subject,String Text){
//function works for send mail
	String Msg;
    
        final String username = Email;
        final String password = Password;

        Properties props = new Properties();
        props.put("mail.smtp.auth", true);
        props.put("mail.smtp.starttls.enable", true);
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
    props.setProperty("mail.smtp.ssl.trust", "smtp.gmail.com");
   // Session session = Session.getDefaultInstance(props, new GMailAuthenticator("xxxxx@gmail.com", "xxxxx"));
     //  session.setDebug(true);
       Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {

           Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(Email));//ur email
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(ToEmail));//u will send to
            message.setSubject(Subject);
            message.setText(Text);
            Transport.send(message);
            Msg="true";
    	    return Msg;

        } catch (Exception e) {
            return e.toString();
        }
    
    
    
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        pname = new javax.swing.JLabel();
        pnamein = new javax.swing.JTextField();
        phone = new javax.swing.JLabel();
        numberin = new javax.swing.JTextField();
        date = new javax.swing.JLabel();
        place = new javax.swing.JLabel();
        from = new javax.swing.JLabel();
        to = new javax.swing.JLabel();
        toin = new javax.swing.JTextField();
        quantity = new javax.swing.JLabel();
        quantityin = new javax.swing.JTextField();
        price = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        pricein = new javax.swing.JTextField();
        seat = new javax.swing.JLabel();
        emailin = new javax.swing.JTextField();
        seatin = new javax.swing.JTextField();
        submitin = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        datein = new com.toedter.calendar.JDateChooser();
        fromin = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jTextField1.setBackground(new java.awt.Color(255, 255, 0));
        jTextField1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(0, 0, 240));
        jTextField1.setText("WELCOME");
        getContentPane().add(jTextField1);
        jTextField1.setBounds(320, 10, 200, 70);

        pname.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        pname.setForeground(new java.awt.Color(240, 0, 0));
        pname.setText("Passanger Name :");
        getContentPane().add(pname);
        pname.setBounds(0, 139, 220, 40);

        pnamein.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pnamein.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pnameinActionPerformed(evt);
            }
        });
        getContentPane().add(pnamein);
        pnamein.setBounds(240, 140, 300, 40);

        phone.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        phone.setForeground(new java.awt.Color(255, 200, 0));
        phone.setText("Phone Number :");
        getContentPane().add(phone);
        phone.setBounds(0, 230, 220, 30);

        numberin.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        numberin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numberinActionPerformed(evt);
            }
        });
        getContentPane().add(numberin);
        numberin.setBounds(240, 220, 310, 40);

        date.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        date.setForeground(new java.awt.Color(255, 0, 0));
        date.setText("Date :-");
        getContentPane().add(date);
        date.setBounds(10, 440, 100, 40);

        place.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        place.setForeground(new java.awt.Color(0, 255, 0));
        place.setText("Place :");
        getContentPane().add(place);
        place.setBounds(10, 300, 100, 40);

        from.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        from.setForeground(new java.awt.Color(255, 0, 0));
        from.setText("From :-");
        getContentPane().add(from);
        from.setBounds(140, 300, 66, 30);

        to.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        to.setForeground(new java.awt.Color(0, 255, 0));
        to.setText("TO :-");
        getContentPane().add(to);
        to.setBounds(140, 370, 60, 22);

        toin.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        getContentPane().add(toin);
        toin.setBounds(250, 360, 280, 40);

        quantity.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        quantity.setForeground(new java.awt.Color(255, 0, 0));
        quantity.setText("Quantity :-");
        getContentPane().add(quantity);
        quantity.setBounds(630, 140, 120, 50);

        quantityin.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        quantityin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quantityinActionPerformed(evt);
            }
        });
        getContentPane().add(quantityin);
        quantityin.setBounds(780, 140, 80, 30);

        price.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        price.setForeground(new java.awt.Color(0, 255, 255));
        price.setText("Price :-");
        getContentPane().add(price);
        price.setBounds(630, 230, 90, 22);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 51));
        jLabel1.setText("Email :-");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(610, 340, 100, 30);

        pricein.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        pricein.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceinActionPerformed(evt);
            }
        });
        getContentPane().add(pricein);
        pricein.setBounds(790, 230, 80, 30);

        seat.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        seat.setForeground(new java.awt.Color(255, 255, 0));
        seat.setText("Seat :-");
        getContentPane().add(seat);
        seat.setBounds(630, 280, 60, 40);
        getContentPane().add(emailin);
        emailin.setBounds(760, 342, 180, 30);

        seatin.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        seatin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                seatinActionPerformed(evt);
            }
        });
        getContentPane().add(seatin);
        seatin.setBounds(780, 290, 70, 30);

        submitin.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        submitin.setText("Submit");
        submitin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitinActionPerformed(evt);
            }
        });
        getContentPane().add(submitin);
        submitin.setBounds(790, 460, 130, 37);

        delete.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        delete.setText("Delete");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        getContentPane().add(delete);
        delete.setBounds(670, 460, 110, 40);
        getContentPane().add(datein);
        datein.setBounds(240, 442, 200, 30);
        getContentPane().add(fromin);
        fromin.setBounds(260, 282, 270, 50);

        jLabel2.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 240, 240));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cg_nedded/bus2.jpg"))); // NOI18N
        jLabel2.setText("DATE:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 980, 530);

        setSize(new java.awt.Dimension(982, 648));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void quantityinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quantityinActionPerformed
boo=true;

 quantityout = Integer.parseInt(quantityin.getText());//convert string to integer
        quantityn=quantityout;
    }//GEN-LAST:event_quantityinActionPerformed

    private void priceinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceinActionPerformed
    if (boo==true){
        int x = quantityout *500;//determine seat price
    
   // String pr =Integer.toString(x);
    String pa=String.format("%d", x);
    pricein.setText(pa);//set the price 
   pricein.getText();
       }
  
    }//GEN-LAST:event_priceinActionPerformed

    private void submitinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitinActionPerformed
String seatno=seatin.getText();
boolean val= true;
        /*pnamein.setText(null);
   numberin.setText(null);
   fromin.setText(null);
   toin.setText(null);
   datein.setText(null);
   quantityin.setText(null);
   pricein.setText(null);
   seatin.setText(null);*/
        String p,pl;
        int n,q;
       
         String seat2=seatin.getText();
          int seat1= Integer.parseInt(seat2);
         pasangername = pnamein.getText();
         name=pasangername;

        int number1 = Integer.parseInt(numberin.getText());
        contact=number1;

        String place = toin.getText();
        placen=place;

        quantityout = Integer.parseInt(quantityin.getText());
        quantityn=quantityout;
    new Crud_panel(pnamein.getText(),number1,quantityn,place,seat1);//passing values to crud_panel
        try {
            Statement smt = con.createStatement();
            //smt.execute("insert into Bus(Name,Phonenumber,Quantity,Place) values('"+pasangername+"',"+number+","+quantity+",'"+place+"')");
                    String sql = "INSERT INTO bus1(Name,Quantity,Place,phonenumber,Seat) VALUES('" +pasangername+ "','" +quantityout+ "','" + placen + "','" + number1 + "','" + seat1 + "')";//for submittion
                  String Sql1="Select * from bus1 where Seat='"+seat1+"'";//for avoiding double seat
                  ResultSet rs = smt.executeQuery("SELECT*FROM bus1");
                   while(rs.next()){ 
                  String seatcheck = rs.getString("Seat");
                  if (seatin.getText().equals(seatcheck)){ //if the seat was booked then the given program will closed
  
   JOptionPane.showMessageDialog(this, "Seat booked before ");
   val= false;
   System.exit(0);//exit from the program
}
                  
                   }
                   
              if(val){       //if the given  seat is not booked before then it will be submitted
                    smt.execute(sql);
      //smt.execute("insert into bus1(Name,Quantity,Place,phonenumber,Seat) values('"+pasangername+"',"+quantity+",'"+placen+"','"+number1+"',"+seat1+")");
           //smt.execute("INSERT INTO bus1(Name,Quantity, Place,phonenumber,Seat) VALUES ('name',quantity,'place',contact,seat1)");
        //  "INSERT INTO users(username, password, name, surname, email, role) VALUES (?, ?, ?, ?, ?)";
     //   smt.execute("INSERT INTO bus1(Name,Phonenumber,Quantity,Place,Seat)VALUES('$name','$number1','$quantity','$placen','$seat1')");
            JOptionPane.showMessageDialog(this, "data submitted");
             smt.close();
            pnamein.setText(null);
            numberin.setText(null);
            fromin.setText(null);
            toin.setText(null);
           // datein.setText(null);
            quantityin.setText(null);
            pricein.setText(null);
            seatin.setText(null);
             String EMAIL="shahalam.tasin@gmail.com";//mail send from this email
        String PW="tousif2012";//emaill pass
        String To=emailin.getText();// mail send to this  mailadressholder
        String SUBJECT="Ticket Booking";
         Date now = new Date();
        now= datein.getDate();//convert date to string
        String MESGE="Ticket confromed ,your seat no is  "+seatno+"  and journey date is "+now.toString();
        
        String DATA=new Datashow().sendMail(EMAIL, PW, To, SUBJECT, MESGE);//pass value to the sendmail function
        System.out.println(DATA);
        
        if(DATA.equals("true")){
        
            JOptionPane.showMessageDialog(this,"Email Send Successfull !");
        
        }else{
        
            JOptionPane.showMessageDialog(this,"Email send Faild !"); //if any error occur
        }
              }
        }catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex);
            System.out.println(ex);
        }

      
       
      
          Crud_panel info1 = new Crud_panel();
        
        info1.setVisible(true);
        super.setVisible(false);
         
    }//GEN-LAST:event_submitinActionPerformed

    private void pnameinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pnameinActionPerformed
     
    }//GEN-LAST:event_pnameinActionPerformed

    private void numberinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numberinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_numberinActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
      busseat= Integer.parseInt(seatin.getText());//booking delete part
        if(busseat!=0) //checking if there any seat  booked before
        {
            try{
            
                Statement smt = con.createStatement();
                 smt.execute("delete from Bus where Seat="+busseat);// delete  booking
                  JOptionPane.showMessageDialog(this, "record deleted");
                
                    }
           catch( Exception ex)
      {
             JOptionPane.showMessageDialog(this, "can not delete data");
      }
             Crud_panel info1 = new Crud_panel();

        info1.setVisible(true);
        new Login().setVisible(false);
             
        }
        
    }//GEN-LAST:event_deleteActionPerformed

    private void seatinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_seatinActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_seatinActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Datashow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Datashow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Datashow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Datashow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Datashow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel date;
    private com.toedter.calendar.JDateChooser datein;
    private javax.swing.JButton delete;
    private javax.swing.JTextField emailin;
    private javax.swing.JLabel from;
    private javax.swing.JTextField fromin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField numberin;
    private javax.swing.JLabel phone;
    private javax.swing.JLabel place;
    private javax.swing.JLabel pname;
    public javax.swing.JTextField pnamein;
    private javax.swing.JLabel price;
    private javax.swing.JTextField pricein;
    private javax.swing.JLabel quantity;
    private javax.swing.JTextField quantityin;
    private javax.swing.JLabel seat;
    private javax.swing.JTextField seatin;
    private javax.swing.JButton submitin;
    private javax.swing.JLabel to;
    private javax.swing.JTextField toin;
    // End of variables declaration//GEN-END:variables

    private String DoubletoString(double c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 /* public static  void modify(boolean h,String pname,String to,int quan,int number)
    {
        String num=Integer.toString(number);
        String qua =Integer.toString(quan);
         pnamein.setText(pasangername);
            numberin.setText(num);
           // fromin.setText(null);
            toin.setText(to);
           // datein.setText(null);
            quantityin.setText(qua);
            //pricein.setText(null);
           // seatin.setText(null);
        
    }*/
}
